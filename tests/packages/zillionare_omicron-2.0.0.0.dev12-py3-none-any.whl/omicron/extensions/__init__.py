from omicron.extensions.decimals import *
from omicron.extensions.np import *
