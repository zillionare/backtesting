TRADE_PRICE_LIMITS = "trade_price_limits"
