bars_1d.pkl, bars_1m.pkl,包含了天域生态、海联金汇到3月14日止前10天的日线和分钟线，用以撮合成交和提供收盘价数据（未复权，带复权因子）。

limits.pkl包含了天域生态、海联金汇到3月14日止前10天的涨跌停价数据，未复权。

hljh_1d.csv, hljh_1m.csv, hljh_limits.csv, tyst_limits.csv等文件内容与上述pkl一致。提供的目的是便于查看和比较数据。
